<?php
    if($page_actual[$cant_p]=='index'){
        $descripcion = 'Brand new NFTLegacies is being for two months in the market. Its first launch was the Golden Monkeyss Collection';
        $titles = "Golden Monkeyss";
    }